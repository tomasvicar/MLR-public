"""Transcribe a recording with Whisper and burn the subtitles into a video.

Uses ffmpeg (must be on PATH) and faster-whisper (CPU). Works for a video or
an audio-only file; audio gets a plain background. Outputs in build/:
<name>.srt, <name>_subtitled.mp4 and a short <name>.gif preview.
"""
import argparse
import subprocess
from pathlib import Path

from faster_whisper import WhisperModel


def timestamp(seconds):
    ms = round(seconds * 1000)
    return f"{ms // 3600000:02}:{ms // 60000 % 60:02}:{ms // 1000 % 60:02},{ms % 1000:03}"


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("--model", default="base", help="tiny, base, small, ...")
parser.add_argument("--language", default=None, help="e.g. en, cs; detected if omitted")
args = parser.parse_args()
source = Path(args.input).resolve()
out = Path(__file__).resolve().parent / "build"
out.mkdir(exist_ok=True)
srt = out / f"{source.stem}.srt"
video = out / f"{source.stem}_subtitled.mp4"

segments, info = WhisperModel(args.model, device="cpu", compute_type="int8").transcribe(
    str(source), language=args.language)
with open(srt, "w", encoding="utf-8") as handle:
    for i, seg in enumerate(segments, start=1):
        handle.write(f"{i}\n{timestamp(seg.start)} --> {timestamp(seg.end)}\n{seg.text.strip()}\n\n")
print(f"language {info.language}, {info.duration:.1f} s -> {srt}")

has_video = subprocess.run(
    ["ffprobe", "-v", "error", "-select_streams", "v", "-show_entries", "stream=index",
     "-of", "csv=p=0", str(source)], capture_output=True, text=True, check=True).stdout.strip()
# Run ffmpeg inside build/ so the subtitles filter gets a plain relative path (Windows-safe).
inputs = ["-i", str(source)] if has_video else [
    "-f", "lavfi", "-i", "color=c=0x12355b:s=1280x720:r=25", "-i", str(source), "-shortest"]
subprocess.run(["ffmpeg", "-y", "-v", "error", *inputs, "-vf", f"subtitles={srt.name}",
                "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", video.name],
               cwd=out, check=True)
subprocess.run(["ffmpeg", "-y", "-v", "error", "-t", "6", "-i", video.name, "-vf",
                "fps=8,scale=480:-1,split[a][b];[a]palettegen[p];[b][p]paletteuse",
                f"{source.stem}.gif"], cwd=out, check=True)
print(video)
