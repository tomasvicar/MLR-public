"""Generate a valid parametric cable clip in millimetres (CadQuery 2.6.1)."""
import argparse
import json
from pathlib import Path

import cadquery as cq


def build(opening=12.0):
    if not 6 <= opening <= 14:
        raise ValueError("This compact demo supports openings from 6 to 14 mm")
    base_length, base_width, base_height = 40., 20., 4.
    wall, loop_depth = 2., 8.
    radius = opening / 2
    centre_z = radius + 5  # Opening bottom at 5 mm; ring overlaps base by 1 mm.
    base = (cq.Workplane("XY").box(base_length, base_width, base_height,
                                  centered=(True, True, False))
            .faces(">Z").workplane().pushPoints([(-14, 0), (14, 0)]).hole(4))
    loop = (cq.Workplane("YZ", origin=(-loop_depth / 2, 0, centre_z))
            .circle(radius + wall).circle(radius).extrude(loop_depth))
    model = base.union(loop).clean()
    solid = model.val()
    assert len(model.solids().vals()) == 1 and solid.isValid()
    # The loop axis is X; test material immediately inside/outside its opening.
    assert not solid.isInside((0, radius - .01, centre_z))
    assert solid.isInside((0, radius + .01, centre_z))
    assert not solid.isInside((14, 0, 2))  # Mounting bore is empty.
    assert solid.isInside((14, 2.01, 2))
    assert abs(solid.BoundingBox().xlen - base_length) < 1e-6
    return model, {"units": "mm", "opening_diameter": opening, "wall": wall,
                   "mounting_hole_diameter": 4, "hole_spacing": 28,
                   "base": [40, 20, 4], "loop_axis": "X",
                   "volume_mm3": solid.Volume()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--opening", type=float, default=12)
    parser.add_argument("--output", type=Path, default=Path("build"))
    args = parser.parse_args()
    model, dimensions = build(args.opening)
    args.output.mkdir(parents=True, exist_ok=True)
    for suffix in ["step", "stl"]:
        cq.exporters.export(model, str(args.output / f"clip.{suffix}"))
    (args.output / "dimensions.json").write_text(json.dumps(dimensions, indent=2) + "\n")
    print(json.dumps(dimensions, indent=2))
