"""Excel workbook with live formulas and a chart, plus a one-page Word summary.

Input: the lab's leaves.csv (Leaf height, Leaf width, Tree type).
Output: build/leaves.xlsx and build/leaves.docx.
"""
import argparse
import csv
from collections import Counter
from io import BytesIO
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from docx import Document
from docx.shared import Cm
from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Font, PatternFill

parser = argparse.ArgumentParser()
parser.add_argument("--data", default="leaves.csv")
args = parser.parse_args()
with open(args.data, newline="") as handle:
    rows = list(csv.DictReader(handle))
counts = Counter(row["Tree type"] for row in rows)
classes = sorted(counts)
out = Path(__file__).resolve().parent / "build"
out.mkdir(exist_ok=True)

# Excel: raw data, then a summary computed by formulas, so editing data updates it.
book = Workbook()
data = book.active
data.title = "data"
data.append(["Leaf height", "Leaf width", "Tree type"])
for row in rows:
    data.append([float(row["Leaf height"]), float(row["Leaf width"]), row["Tree type"]])
last = len(rows) + 1
summary = book.create_sheet("summary")
summary.append(["Tree type", "Count", "Mean height", "Mean width"])
for i, name in enumerate(classes, start=2):
    summary.append([name, f'=COUNTIF(data!C2:C{last},A{i})',
                    f'=AVERAGEIF(data!C2:C{last},A{i},data!A2:A{last})',
                    f'=AVERAGEIF(data!C2:C{last},A{i},data!B2:B{last})'])
total = len(classes) + 2
summary.append(["Total", f"=SUM(B2:B{total - 1})"])
for cell in summary[1]:
    cell.font = Font(bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor="1E88BC")
for column in "CD":
    for cell in summary[column][1:]:
        cell.number_format = "0.00"
summary.column_dimensions["A"].width = 14
chart = BarChart()
chart.title = "Leaves per tree type"
chart.y_axis.title = "Count"
chart.add_data(Reference(summary, min_col=2, min_row=1, max_row=total - 1), titles_from_data=True)
chart.set_categories(Reference(summary, min_col=1, min_row=2, max_row=total - 1))
summary.add_chart(chart, "F2")
book.save(out / "leaves.xlsx")

# Word: a heading, a short text, a table and a figure. Numbers come from Python.
fig, ax = plt.subplots(figsize=(6, 3.5))
for name in classes:
    pts = [(float(r["Leaf width"]), float(r["Leaf height"])) for r in rows if r["Tree type"] == name]
    ax.scatter(*zip(*pts), s=10, label=name)
ax.set(xlabel="Leaf width", ylabel="Leaf height")
ax.legend()
fig.tight_layout()
image = BytesIO()
fig.savefig(image, format="png", dpi=150)
plt.close(fig)
doc = Document()
doc.add_heading("Leaf data summary", level=1)
doc.add_paragraph(f"The dataset has {len(rows)} leaves of {len(classes)} tree types.")
table = doc.add_table(rows=1, cols=2)
table.style = "Light Grid Accent 1"
table.rows[0].cells[0].text, table.rows[0].cells[1].text = "Tree type", "Count"
for name in classes:
    cells = table.add_row().cells
    cells[0].text, cells[1].text = name, str(counts[name])
doc.add_picture(image, width=Cm(15))
doc.save(out / "leaves.docx")
print(out / "leaves.xlsx", out / "leaves.docx")
