# Exercise 6 — agent task materials

<p style="color: #c00000;"><strong>! Compulsory hand-in: complete and submit Task 5b within 48 hours after your lab. Attendance will not be credited unless you complete this requirement.</strong></p>

Extract the ZIP into a new folder. It contains:

- `ex06_notebook.ipynb`: the current student notebook, including starter code.
- `ex06_ebikes.csv`: the data used in Tasks 4 and 5.
- `TASK.md`: the complete agent specification, hand-in rules and review checklist.

## When to use AI agents

- **Tasks 1–4: work without AI agents.** Write and understand the code yourself. Use the supplied starter code, API hints and teacher help.
- **Task 5a: follow the teacher demonstration.** The demonstration code is supplied.
- **Task 5b: use your coding agent.** Have it extend **your own completed Task 4 pipeline**, implement the comparison, run experiments and generate the report.
- **Your review is your own work.** Check the agent's output and write `REVIEW.md` yourself; do not ask the agent to write it.

## Start from your own work

Download your completed or partially completed notebook from Colab/Jupyter.
Replace the bundled blank `ex06_notebook.ipynb` with **your own notebook**;
keep your original copy safe. Finish your Task 4 pipeline and feature experiment
before starting the agent extension. The bundled notebook is a starting copy,
not a substitute for your own work or a completed solution.

Keep the CSV next to the notebook: the e-bike loader uses it automatically.
For Colab, upload the notebook and CSV. The earlier leaf tasks use their existing
online data link; only the e-bike data are needed for the final task.

**Optional editor:** if you want to use VS Code on Windows, install it from PowerShell or Windows Terminal:

```powershell
winget install --id Microsoft.VisualStudioCode --exact --scope user --accept-package-agreements --accept-source-agreements
```

Open this folder in the coding agent you set up in the fifth lab. Ask it to
read your notebook and follow the specification in `TASK.md`. It should first
check that the required Task 4 work is complete, then create the comparison
scripts and dependency files. Start with the validation-only smoke run from
the specification before running the full comparison.

Create a **private** repository `mlr-ex06`, invite **MLRteacher**, and follow
the hand-in checklist in `TASK.md`. You write `REVIEW.md` yourself. The ZIP
contains the input materials; the comparison code, results and review are
the work you and your agent produce.

If GitHub CLI (`gh`) is installed and authenticated (`gh auth status`), you can simply ask your coding agent:

> Use `gh` to invite `MLRteacher` as a collaborator to my private `mlr-ex06` repository. Check the repository owner and confirm that the invitation is pending or access already exists.

Your signed-in GitHub account must have permission to manage collaborators for that repository.
