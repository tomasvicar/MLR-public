// Teacher demo: identify the actual board and port before compiling/uploading.
const unsigned long interval_ms = 500;
void setup() { pinMode(LED_BUILTIN, OUTPUT); }
void loop() {
  digitalWrite(LED_BUILTIN, HIGH);
  delay(interval_ms);
  digitalWrite(LED_BUILTIN, LOW);
  delay(interval_ms);
}
