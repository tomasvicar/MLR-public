"""Run: blender --background --factory-startup --python blender_scene.py

Creates a NEW scene in the process; does not open or modify an existing file.
"""
from pathlib import Path
from math import radians
import bpy
from mathutils import Vector

out = Path(__file__).resolve().parent / "build"
out.mkdir(exist_ok=True)
# A new scene avoids deleting objects from a user's scene even on accidental GUI use.
scene = bpy.data.scenes.new("Leaf demonstration")
bpy.context.window.scene = scene


def material(name, colour):
    result = bpy.data.materials.new(name)
    result.diffuse_color = (*colour, 1)
    return result


def ellipsoid(name, location, scale, colour, rotation=0):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=32, ring_count=16, location=location)
    obj = bpy.context.object; obj.name = name; obj.scale = scale
    obj.rotation_euler.z = radians(rotation)
    obj.data.materials.append(material(name, colour))
    for polygon in obj.data.polygons: polygon.use_smooth = True
    return obj


bpy.ops.mesh.primitive_cube_add(location=(0,0,-.17))
table = bpy.context.object; table.name = "Table"; table.scale = (4,3,.15)
table.data.materials.append(material("Table", (.32,.21,.12)))
for x,y,angle,colour in [(-1.5,0,-20,(.20,.50,.10)),(0,.35,15,(.50,.66,.12)),
                         (1.5,-.1,-35,(.72,.28,.07))]:
    ellipsoid("Stylised leaf", (x,y,.12), (.55,1,.13), colour, angle)
    ellipsoid("Leaf vein", (x,y,.23), (.025,.83,.02), (.64,.72,.22), angle)
bpy.ops.object.camera_add(location=(6,-8,7))
camera=bpy.context.object
camera.rotation_euler=(Vector((0,0,0))-camera.location).to_track_quat('-Z','Y').to_euler()
scene.camera=camera; camera.data.lens=45
bpy.ops.object.light_add(type='AREA', location=(1,-3,7))
bpy.context.object.data.energy=1000; bpy.context.object.data.shape='DISK'
bpy.context.object.data.size=5
scene.world = bpy.data.worlds.new("Soft world")
scene.world.color=(.3,.3,.3)
scene.render.engine='CYCLES'; scene.cycles.samples=32
scene.render.resolution_x=1000; scene.render.resolution_y=650
scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
scene.render.filepath=str(out/'leaves.png')
bpy.ops.wm.save_as_mainfile(filepath=str(out/'scene.blend'))
bpy.ops.render.render(write_still=True)
