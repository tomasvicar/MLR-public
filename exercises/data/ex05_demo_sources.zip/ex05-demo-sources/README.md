# Small runnable teacher demonstrations

These original examples accompany the capability-tour prompts. They provide a
reproducible fallback, not a claim that every agent produces identical output.
Run commands **from this directory**. Generated files live in ignored `build/`;
rendered HTML/PDF are ignored too. Inspect existing generated output before
rerunning if you have made manual changes to it.

## CAD, browser action, animation and slides

```bash
uv run --with cadquery==2.6.1 python cable_clip.py --opening 12 --output build
uv run --with matplotlib --with pillow --with numpy python make_animation.py
quarto render demo.qmd
python -m http.server 8015 --bind 127.0.0.1
```

In the course repository use `uv run quarto render demo.qmd` instead of the
standalone `quarto` command. Open `http://127.0.0.1:8015/` for the Three.js viewer
and `/demo.html` for the five-slide deck. The viewer uses pinned Three.js 0.180.0
modules from jsDelivr, so it needs network access on first load. All local asset
paths are relative and also work under a GitHub Pages project prefix.

The base is 40 × 20 × 4 mm; mounting bores are 4 mm diameter, 28 mm apart.
The central loop's opening runs along **X**, with 2 mm walls and 8 mm axial
depth. Its bottom overlaps the base by 1 mm, making a single solid. `--opening
10` demonstrates the initial design; rerun at 12 for the final deck/note.
The GIF is a generated **YZ cross-section**, not a 3D render. It starts with
the final 12 mm state, then animates 10–12 mm and holds the final frame.

Browser automation in an isolated Chromium context:

```bash
uv run --with playwright python -m playwright install chromium
uv run --with playwright python check_viewer.py
```

This starts its own temporary local server, loads the actual STL, clicks the
theme toggle, downloads the mesh, checks page errors and saves screenshots.
If the rendered deck exists, it also checks there are five slides and captures
each one. Review `build/viewer.png` and `build/slide-*.png` yourself.

To publish after reviewing, copy `index.html`, generated `build/clip.stl`,
`build/clip.step` and `build/dimensions.json` into your demo repository's `docs/`
with the same relative structure. Commit those **generated publication assets**
explicitly there (this source bundle ignores local outputs). Enable Pages on
`main:/docs` and inspect the published URL; no publication is performed by
these scripts. To publish the deck too, include `demo.html`; the GIF is embedded.

## Blender

```bash
blender --background --factory-startup --python blender_scene.py
```

The script creates a new scene containing three stylised leaf forms on a table,
saves `build/scene.blend` and renders `build/leaves.png`. It does not delete
objects from an existing scene. Change a leaf colour in the script and render
again. It uses CPU Cycles with 32 samples; this is not a photorealistic model.

## LaTeX

After generating the cross-section image at the final 12 mm setting:

```bash
pdflatex -interaction=nonstopmode -halt-on-error note.tex
```

Inspect `note.pdf` for clipping, missing images and its one-page layout. The
text labels geometric checks separately from unperformed physical load tests.

## Excel and Word

```bash
uv run --with openpyxl --with python-docx --with matplotlib python office_report.py --data leaves.csv
```

Writes `build/leaves.xlsx` (data sheet, summary by `COUNTIF`/`AVERAGEIF`
formulas, bar chart) and `build/leaves.docx` (heading, count table, scatter
plot). Formulas are evaluated when the file is opened in Excel/LibreOffice;
change a label on the data sheet to show that the summary follows.

## Whisper + ffmpeg

```bash
uv run --with faster-whisper --with "av<16" python subtitles.py recording.m4a --language en
```

Needs `ffmpeg` on PATH (Windows: `winget install Gyan.FFmpeg`). The first run
downloads the Whisper `base` model (~150 MB) — do it before class. Accepts video
or audio (audio gets a plain background). Writes `build/<name>.srt`,
`build/<name>_subtitled.mp4` and a 6-second `build/<name>.gif`. The `av<16` pin
works around faster-whisper 1.2.1 failing with PyAV 16 (`unexpected keyword
argument 'metadata_errors'`, seen 1 October 2026).

## Arduino (teacher only)

```bash
arduino-cli board list
arduino-cli compile --fqbn YOUR_CONFIRMED_BOARD_TARGET blink
arduino-cli upload --fqbn YOUR_CONFIRMED_BOARD_TARGET --port YOUR_CONFIRMED_PORT blink
```

Substitute the actual detected target/port; install its core beforehand.
Compile first, review the upload destination, then authorise upload. Confirm
blinking physically. `interval_ms=500` gives 500 ms on and 500 ms off (1 Hz
full cycle), and `LED_BUILTIN` avoids assuming a pin number.

## Checked versus still to rehearse (29 September 2026)

Added 1 October 2026: `office_report.py` ran on `leaves.csv` (518 rows, three
classes, one chart; formulas inspected with openpyxl, not evaluated, since no
LibreOffice on this host). `subtitles.py` ran on Linux with ffmpeg on an
87-second English narration of the first lecture: the SRT matched the
narration text and a frame showed the burned-in subtitle. Not run on Windows.

Executed here: CadQuery 2.6.1 export at 12 mm with one-valid-solid, aperture,
mounting-bore and base-length assertions; GIF and static figure generation;
Quarto render; Playwright mesh load, theme click, successful STL download,
zero page errors, five-slide count and screenshots. The viewer and all five
slides were visually inspected. The opening and two mounting holes are visible;
slide content fits without overflow.

Blender, `pdflatex` and `arduino-cli` are absent on this preparation host.
Their sources were syntax/read-through checked but **not executed**; render,
PDF layout and hardware checks remain classroom preparation. No GitHub demo
publication, CESNET authentication or Pi transfer was performed here.

API references consulted: [CadQuery](https://cadquery.readthedocs.io/en/latest/classreference.html),
[Three.js](https://threejs.org/docs/),
[Blender Python API](https://docs.blender.org/api/current/).
