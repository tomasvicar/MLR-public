"""Draw a YZ section of the clip; first GIF frame is the final 12 mm design."""
from io import BytesIO
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle
from PIL import Image

out = Path(__file__).resolve().parent / "build"
out.mkdir(exist_ok=True)
openings = [12.] + list(np.linspace(10, 12, 21))
frames = []
for opening in openings:
    radius, centre = opening / 2, opening / 2 + 5
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.add_patch(Circle((0, centre), radius + 2, facecolor="#1e88bc"))
    ax.add_patch(Circle((0, centre), radius, facecolor="white"))
    ax.add_patch(Rectangle((-10, 0), 20, 4, facecolor="#1e88bc"))
    ax.annotate("", xy=(-radius, centre), xytext=(radius, centre),
                arrowprops={"arrowstyle": "<->", "color": "#12355b"})
    ax.text(0, centre + .8, f"{opening:.1f} mm", ha="center", fontsize=16)
    ax.set(xlim=(-22,22), ylim=(-2,22), aspect="equal", xlabel="Y [mm]", ylabel="Z [mm]")
    ax.set_title("Loop opening: YZ cross-section (axis along X)")
    fig.tight_layout()
    buffer = BytesIO(); fig.savefig(buffer, format="png", dpi=120)
    frames.append(Image.open(buffer).convert("RGB")); plt.close(fig)
frames[0].save(out / "clip-section.png")
frames[0].save(out / "opening.gif", save_all=True, append_images=frames[1:],
               duration=[1800] + [90] * (len(frames)-2) + [2200], loop=0)
print(out / "opening.gif")
