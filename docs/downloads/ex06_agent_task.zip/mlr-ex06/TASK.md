### 5b. Start your compulsory agent extension

<p style="color: #c00000;"><strong>! Compulsory hand-in: complete and submit Task 5b within 48 hours after your lab. Attendance will not be credited unless you complete this requirement.</strong></p>

The agent extends **your own e-bike experiment**. You review the result. Use your laptop terminal and the coding agent from the fifth lab. Download this notebook as `ex06_notebook.ipynb`; create a new **private** repository `mlr-ex06`. Your public repository from the fifth lab is not a suitable hand-in location.

**Optional editor:** if you want to use VS Code on Windows, install it from PowerShell or Windows Terminal:

```powershell
winget install --id Microsoft.VisualStudioCode --exact --scope user --accept-package-agreements --accept-source-agreements
```

Share `mlr-ex06` with **MLRteacher**: repository **Settings → Collaborators → Add people → MLRteacher**. A pending invitation is sufficient. Submit by pushing within **48 hours after the end of your lab**. Hand-ins are reviewed automatically by AI.

If GitHub CLI (`gh`) is installed and authenticated (`gh auth status`), you can simply ask your coding agent:

> Use `gh` to invite `MLRteacher` as a collaborator to my private `mlr-ex06` repository. Check the repository owner and confirm that the invitation is pending or access already exists.

Your signed-in GitHub account must have permission to manage collaborators for that repository.

<p style="color: #c00000;"><strong>! Plagiarism check: all hand-ins will be checked for plagiarism.</strong></p>

If your notebook still contains TODOs in the e-bike pipeline, finish them first or ask the teacher for help. Do not replace your work with a downloaded completed module. Without a working agent, implement the same specification yourself at home.

**Paste this specification to your agent:**

> Extend my `ex06_notebook.ipynb` e-bike experiment. First inspect my code. If required functions or experiments are unfinished, tell me what is missing before proceeding.
>
> 1. Copy my data loading, fixed cleaning rules, feature functions and baseline into `common.py`, with the required imports. Preserve their behavior. Use `ex06_ebikes.csv`, `runs_out` as target, test_size=0.25, stratify=y, random_state=42. Select all features and models using only the training subset and `StratifiedKFold(n_splits=3, shuffle=True, random_state=0)`. Imputation and scaling must be fitted inside each fold. Retain the untouched test subset for final reporting.
> 2. Implement `bayes_compare.py --trials 20`: compare k-NN, SVM, logistic regression, random forest (100 trees), and `HistGradientBoostingClassifier`, using Optuna with the **same number of trials per family**. Trial parameters must be meaningful for the model. Use log scales for C, gamma, learning rate and positive regularization strengths; suggest gamma only for RBF SVM. Tune sensible parameters such as neighbors/weights, C/kernel, minimum leaf size/feature subsampling, or learning rate/leaf count. Do not add a tree-depth experiment. Bound parameters for the sample size.
> 3. Limit preparation choices to numeric mean/median imputation and original/engineered features; preserve the physically motivated cleaning and categorical missing-label + one-hot encoding. Keep my chosen engineered feature set. Use StandardScaler for k-NN, SVM and logistic regression, after numeric feature creation; do not search scalers for trees. Fix the forest's random_state=0 and all other model, sampler and split seeds. Run Optuna sequentially (`n_jobs=1`) for reproducibility.
> 4. Record each trial in `trials.csv` (family, trial number, applied parameters, CV mean and fold SD). Choose the best configuration per family **by CV**, then fix all choices before evaluating on the test subset. Produce `results.csv`: best parameters, best trial number, CV mean and fold SD, final test accuracy. Include my unchanged original-feature forest and the majority-class classifier as reference rows, evaluated with the same folds. Check that the baseline agrees with my notebook. Select the overall winner by CV, not test scores.
> 5. Produce `convergence.png` (best-so-far CV accuracy versus completed trials for each family) and a self-contained `report.html` containing the plot, table, baseline comparison, trial budget, split and seeds, package versions and a cautious conclusion. Fold SD is not a significance test. Report limitations and validation-selection optimism; do not promise a real battery-safety predictor.
> 6. Add `pyproject.toml` and `uv.lock`, a README with commands from a fresh clone and measured runtime. Implement `--cv-only` to skip all test prediction and scoring. Run a small smoke test (`--trials 2 --cv-only`) first, then the full `--trials 20` comparison twice; verify identical `results.csv`. Save my notebook too. Do not write `REVIEW.md`: that is my own work.

**Required files:** `common.py`, `bayes_compare.py`, `ex06_notebook.ipynb`, dependency files, `README.md`, `trials.csv`, `results.csv`, `convergence.png`, `report.html`, and your own `REVIEW.md`. Include any additional modules or data required to reproduce the run. Finish the full run and review at home; no particular laptop runtime is promised.

**Your eight-point review — write evidence in `REVIEW.md`, yourself:**

1. **Preprocessing inside CV:** locate the full pipeline in the objective; check that imputation and scaling are never fitted on validation/test rows. Confirm the fixed cleaning bounds and safe ratios.
2. **Test isolation:** find every use of X_test/y_test. Were all model and feature choices fixed before these scores were calculated? No post-trip variables or target-derived features may enter X.
3. **Fair comparison:** count completed trials, compare folds and data rows across algorithms, and verify the two reference rows. Equal trial counts do not imply equal compute effort.
4. **Search ranges:** inspect logarithmic versus linear ranges, sensible neighbor/leaf bounds and the limited feature/preparation choices. Are all returned parameters applied?
5. **Conditional parameters:** gamma only for RBF; scaling for the distance/linear models, not a meaningless tree scaling search. Check the best parameter dictionaries.
6. **Reproducibility:** inspect every seed and compare the two full-run CSVs. Record the command and evidence; do not include runtime in a table expected to be byte-identical.
7. **Agreement with your work:** compare the original-feature forest with Task 4 and explain any discrepancy. Look at convergence and whether extra features helped. Large gains deserve investigation, not automatic acceptance.
8. **Conclusions:** distinguish validation selection from final testing. Compare differences with fold variability without treating it as a formal significance test. State what synthetic data cannot establish about real e-bikes.

For each point record the location (file/line or notebook cell), what you checked, your finding, and how any problem was fixed. “No problem found” needs evidence too. The agent writes the code and generated report; **you write the review**.